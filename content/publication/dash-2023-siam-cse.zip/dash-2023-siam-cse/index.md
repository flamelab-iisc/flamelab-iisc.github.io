---
title: "Reconstruction of unresolved small-scale structures in isotropic turbulence using deep learning"
date: 2023-03-03
publishDate: 2023-03-03T20:49:33.542875Z
authors: ["Priyabrat Dash", "Konduri Aditya"]
publication_types: ["1"]
abstract: ""
featured: false
publication: "*2023 SIAM Conference on Computational Science and Engineering*"
doi: ""
tags: ["super-resolution", "turbulence", "deep learning"]
share: false
---


---
title: "Poster: Asynchronous Computing for Partial Differential Equations at Extreme Scales"
date: 2012-01-01
publishDate: 2020-06-20T20:49:33.542875Z
authors: ["Aditya Konduri", "Diego A Donzis"]
publication_types: ["1"]
abstract: ""
featured: false
publication: "*2012 SC Companion: High Performance Computing, Networking Storage and Analysis*"
doi: "10.1109/SC.Companion.2012.247"
tags: ["async"]
---

